import React, { useState } from "react";
import { Container, Form, Button, Alert } from "react-bootstrap";
import axios from "axios";

const customerDeposit = () =>{
    const [Deposit,setDeposit]= useState({



        
    })
}