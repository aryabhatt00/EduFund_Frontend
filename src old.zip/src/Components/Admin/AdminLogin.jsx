// components/AdminLogin.js
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const AdminLogin = () => {
  const [input, setInput] = useState({ username: '', password: '' });
  const [error, setError] = useState('');
  const navigate = useNavigate(); // Used to redirect after login

  const handleChange = (e) => {
    setInput({ ...input, [e.target.name]: e.target.value });
    setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch('http://localhost:8080/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(input),
      });

      if (!res.ok) {
        setError('Invalid login');
        return;
      }

      const data = await res.json(); // ✅ Parse token
      console.log('Login response:', data);

      if (data.token) {
        localStorage.setItem('token', data.token); // ✅ Store token
        navigate('/admin'); // ✅ Redirect after successful login
      } else {
        setError('Login failed: Token not found');
      }
    } catch (err) {
      console.error('Login error:', err);
      setError('Server error');
    }
  };

  return (
    <form onSubmit={handleSubmit} style={{ maxWidth: '300px', margin: '0 auto' }}>
      <h2>Admin Login</h2>
      <input
        name="username"
        placeholder="Username"
        value={input.username}
        onChange={handleChange}
        style={{ display: 'block', width: '100%', marginBottom: '10px' }}
      />
      <input
        name="password"
        type="password"
        placeholder="Password"
        value={input.password}
        onChange={handleChange}
        style={{ display: 'block', width: '100%', marginBottom: '10px' }}
      />
      <button type="submit" style={{ width: '100%' }}>Login</button>
      {error && <p style={{ color: 'red', marginTop: '10px' }}>{error}</p>}
    </form>
  );
};

export default AdminLogin;
