import React, { useState } from 'react';
import { Container, Form, Button, Alert } from 'react-bootstrap';

const DeleteAccount = () => {
  const [accountNumber, setAccountNumber] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const handleDelete = async (e) => {
    e.preventDefault();
    setMessage('');
    setError('');

    const token = localStorage.getItem("token");

    try {
      const res = await fetch(`http://localhost:8080/admin/account/${accountNumber}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      const text = await res.text();

      if (res.ok) {
        setMessage(text);
      } else {
        setError(text);
      }
    } catch (err) {
      setError('Something went wrong. Please try again.');
    }
  };

  return (
    <Container className="mt-5">
      <h3>Admin: Delete Account by Account Number</h3>
      <Form onSubmit={handleDelete}>
        <Form.Group className="mb-3">
          <Form.Label>Enter Account Number</Form.Label>
          <Form.Control
            type="text"
            value={accountNumber}
            onChange={(e) => setAccountNumber(e.target.value)}
            placeholder="Enter Account Number"
            required
          />
        </Form.Group>
        <Button variant="danger" type="submit">Delete Account</Button>
      </Form>

      {message && <Alert variant="success" className="mt-3">{message}</Alert>}
      {error && <Alert variant="danger" className="mt-3">{error}</Alert>}
    </Container>
  );
};

export default DeleteAccount;
