// src/components/AppNavbar.jsx
import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Navbar, Nav, Container } from 'react-bootstrap';

const AppNavbar = () => {
  const [loggedIn, setLoggedIn] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const updateLoginStatus = () => {
      const status = localStorage.getItem("isLoggedIn");
      setLoggedIn(status === "true");
    };

    updateLoginStatus(); // Initial check
    window.addEventListener("storage", updateLoginStatus); // Listen for changes
    return () => window.removeEventListener("storage", updateLoginStatus);
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("isLoggedIn");
    localStorage.removeItem("customerToken");
    localStorage.removeItem("customerName");
    localStorage.removeItem("customerEmail");
    navigate("/customer/login");
    window.dispatchEvent(new Event("storage")); // Notify other components
  };

  return (
    <Navbar bg="dark" variant="dark" expand="lg">
      <Container>
        <Navbar.Brand as={Link} to="/">Your Bank</Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto">
            {!loggedIn ? (
              <>
                <Nav.Link as={Link} to="/customer/create">Create Account</Nav.Link>
                <Nav.Link as={Link} to="/customer/login">Login</Nav.Link>
              </>
            ) : (
              <>
                <Nav.Link as={Link} to="/transactions?type=Deposit">Deposit</Nav.Link>
                <Nav.Link as={Link} to="/transactions?type=Withdraw">Withdraw</Nav.Link>
                <Nav.Link as={Link} to="/transactions">Transactions</Nav.Link>
                <Nav.Link onClick={handleLogout}>Logout</Nav.Link>
              </>
            )}
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
};

export default AppNavbar;
