import React, { useState, useEffect } from "react";
import { Container, Row, Col } from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom";
import "./Home.css";
import logo from "../../Assets/logo.png";

const CenteredSplitContainer = () => {
  const navigate = useNavigate();
  const [isLoggedIn, setIsLoggedIn] = useState(localStorage.getItem("isLoggedIn") === "true");
  const [customerInfo, setCustomerInfo] = useState(null);

  useEffect(() => {
    const updateState = () => {
      const loggedIn = localStorage.getItem("isLoggedIn") === "true";
      setIsLoggedIn(loggedIn);

      if (loggedIn) {
        const name = localStorage.getItem("customerName");
        const email = localStorage.getItem("customerEmail");
        setCustomerInfo({ name, email });
      } else {
        setCustomerInfo(null);
      }
    };

    updateState();
    window.addEventListener("storage", updateState);
    return () => window.removeEventListener("storage", updateState);
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("isLoggedIn");
    localStorage.removeItem("customerToken");
    localStorage.removeItem("customerName");
    localStorage.removeItem("customerEmail");
    setIsLoggedIn(false);
    setCustomerInfo(null);
    window.dispatchEvent(new Event("storage"));
    alert("Logged out successfully!");
    navigate("/customer/login");
  };

  return (
    <Container className="d-flex justify-content-center align-items-center min-vh-100">
      <Row
        className="shadow p-4 bg-white rounded mx-auto"
        style={{ width: "60%", maxWidth: "100vw", position: "relative" }}
      >
        {/* 👤 Logged in user info top right */}
        {isLoggedIn && customerInfo && (
          <div style={{ position: "absolute", top: 10, right: 20, textAlign: "right" }}>
            <strong>{customerInfo.name}</strong><br />
            <small>{customerInfo.email}</small>
          </div>
        )}

        <Col md={6} className="p-3">
          <h4>Welcome to Your Bank</h4>
          <p>Manage your bank account efficiently with this simple website.</p>

          <div className="buttons d-flex flex-wrap gap-3 mt-3">
            {isLoggedIn ? (
              <>
                <Link to="/transactions?type=Deposit" className="btn btn-primary">
                  Deposit
                </Link>
                <Link to="/transactions?type=Withdraw" className="btn btn-primary">
                  Withdraw
                </Link>
                <Link to="/transactions" className="btn btn-primary">
                  Transactions
                </Link>
                <Link to="/customer/find" className="btn btn-primary">
                  Find Customer
                </Link>
                <button onClick={handleLogout} className="btn btn-danger">
                  Logout
                </button>
              </>
            ) : (
              <>
                <Link to="/customer/login" className="btn btn-success">
                  Login
                </Link>
                <Link to="/customer/create" className="btn btn-secondary">
                  Register
                </Link>
              </>
            )}
          </div>
        </Col>

        <Col md={6} className="p-3">
          <div className="logo-container">
            <img
              src={logo}
              alt="Bank logo"
              className="img-fluid rounded"
              style={{ width: "100%", maxWidth: "400px" }}
            />
          </div>
        </Col>
      </Row>
    </Container>
  );
};

export default CenteredSplitContainer;
